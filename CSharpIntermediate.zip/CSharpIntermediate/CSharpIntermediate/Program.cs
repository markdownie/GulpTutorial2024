﻿// See https://aka.ms/new-console-template for more information;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpIntermediate
{

    public class Person
    {
        public string Name;

        public void Introduce(string to)
        {
            Console.WriteLine("Hi {0}, I am {1}", to, Name);
        }

        public static Person Parse(string str)
        {
            return new Person { Name = str };
        }
    }


    class Program
    {
        static void Main(string[] args)
        {
            // Create a new object of the class Person - Method one
            var person = new Person();
            person.Name = "John";
            person.Introduce("Mosh");

            // A satic method is only available on the class itself, not the object. 
            // So we can't do this:
            //person.Parse("John")


            // Create a new object using the Static method - Method two
            var personTwo = Person.Parse("Bib");
            personTwo.Introduce("Bob");
        }
    }
}
