﻿namespace MD_001_Alpha_WFApp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBoxInput = new TextBox();
            buttonGo = new Button();
            textBoxOutput = new TextBox();
            label1 = new Label();
            SuspendLayout();
            // 
            // textBoxInput
            // 
            textBoxInput.Location = new Point(57, 76);
            textBoxInput.MaxLength = 1;
            textBoxInput.Name = "textBoxInput";
            textBoxInput.Size = new Size(125, 27);
            textBoxInput.TabIndex = 0;
            // 
            // buttonGo
            // 
            buttonGo.Location = new Point(188, 76);
            buttonGo.Name = "buttonGo";
            buttonGo.Size = new Size(94, 29);
            buttonGo.TabIndex = 1;
            buttonGo.Text = "Lookup";
            buttonGo.UseVisualStyleBackColor = true;
            buttonGo.Click += buttonGo_Click;
            // 
            // textBoxOutput
            // 
            textBoxOutput.Location = new Point(57, 123);
            textBoxOutput.Name = "textBoxOutput";
            textBoxOutput.Size = new Size(125, 27);
            textBoxOutput.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(57, 28);
            label1.Name = "label1";
            label1.Size = new Size(546, 20);
            label1.TabIndex = 3;
            label1.Text = "Type a letter, then press the lookup button to get the the phonetic alphabet letter";
            label1.Click += label1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label1);
            Controls.Add(textBoxOutput);
            Controls.Add(buttonGo);
            Controls.Add(textBoxInput);
            Name = "Form1";
            Text = "Phonetic alphabet letter lookup";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBoxInput;
        private Button buttonGo;
        private TextBox textBoxOutput;
        private Label label1;
    }
}
