using MD001Alpha;
using System.Security.Cryptography.Xml;

namespace MD_001_Alpha_WFApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonGo_Click(object sender, EventArgs e)
        {
            char inputChar = textBoxInput.Text.Length > 0 ? textBoxInput.Text[0] : '\0';
            textBoxOutput.Text = Alpha.wordLookUp(inputChar);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
