﻿

namespace CSharpIntermediate
{
    public class Customer
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public List<Order> Orders { get; set; }

        public Customer()
        {
            // This is a default constructor
            Orders = new List<Order>();
        }

        // In the example below :this() is ensuring we use the Customer()
        // constructor so that we always get the Orders initialised.
        // Only 
        public Customer(int id)
            : this()
        {
            this.Id = id;
        }

        public Customer(int id, string name)
            : this()
        {
            this.Id = id;
            this.Name = name;
        }
    }
}