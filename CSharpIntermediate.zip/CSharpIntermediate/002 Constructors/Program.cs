﻿

namespace CSharpIntermediate
{
    class Progam
    {
        static void Main(string[] args)
        {
            var customer = new Customer();  
           
            customer.Id = 1;
            customer.Name = "John";

            Console.WriteLine(customer.Id);
            Console.WriteLine(customer.Name);

            var customerTwo = new Customer(100);
            customerTwo.Name = "Bob";

            Console.WriteLine(customerTwo.Id);
            Console.WriteLine(customerTwo.Name);


            var customerThree = new Customer(110, "Dave");
            Console.WriteLine(customerThree.Id);
            Console.WriteLine(customerThree.Name);
        }

    }
}