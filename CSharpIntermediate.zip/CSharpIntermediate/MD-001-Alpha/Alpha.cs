﻿namespace MD001Alpha
{
    public class Alpha
    {
        public static string wordLookUp(char inputChar)
        {
            inputChar = char.ToUpper(inputChar); // Convert inputChar to uppercase

            Dictionary<char, string> alphalookup =
            new Dictionary<char, string>();

            alphalookup.Add('A', "Alpha");
            alphalookup.Add('B', "Bravo");
            alphalookup.Add('C', "Charlie");
            alphalookup.Add('D', "Delta");
            alphalookup.Add('E', "Echo");
            alphalookup.Add('F', "Foxtrot");
            alphalookup.Add('G', "Golf");
            alphalookup.Add('H', "Hotel");
            alphalookup.Add('I', "India");
            alphalookup.Add('J', "Juliet");
            alphalookup.Add('K', "Kilo");
            alphalookup.Add('L', "Lima");
            alphalookup.Add('M', "Mike");
            alphalookup.Add('N', "November");
            alphalookup.Add('O', "Oscar");
            alphalookup.Add('P', "Papa");
            alphalookup.Add('Q', "Quebec");
            alphalookup.Add('R', "Romeo");
            alphalookup.Add('S', "Sierra");
            alphalookup.Add('T', "Tango");
            alphalookup.Add('U', "Uniform");
            alphalookup.Add('V', "Victor");
            alphalookup.Add('W', "Whiskey");
            alphalookup.Add('X', "X-ray");
            alphalookup.Add('Y', "Yankee");
            alphalookup.Add('Z', "Zulu");

            if (alphalookup.TryGetValue(inputChar, out string result))
            {
                return result;
            }
            return "Not Found";
        }
    }
}