﻿using System;
using System.Threading;


namespace MD001Alpha
{

    class Program
    {
      
        static void Main(string[] args)
        {
            ConsoleKeyInfo keyInfo;

            Console.WriteLine("Press any key to get the phonetic alphabet letter");
            Console.WriteLine("Press ESC to exit");

            do
            {
               

                keyInfo = Console.ReadKey(true);
               // Console.WriteLine($"{keyInfo}");
               // Console.WriteLine($"Key: {keyInfo.Key}");
               // Console.WriteLine($"KeyChar: {keyInfo.KeyChar}");
               // Console.WriteLine($"GetHashCode(): {keyInfo.GetHashCode()}");
                Console.WriteLine("------------------------------------");
                Console.WriteLine(Alpha.wordLookUp(keyInfo.KeyChar));
                Console.WriteLine("------------------------------------");
                Console.WriteLine();
            } while (keyInfo.Key != ConsoleKey.Escape);
        }
    }
}